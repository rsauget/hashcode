#include <bits/stdc++.h>

using namespace std;

string toString(int i)
{
	ostringstream oss;
	oss<<i;
	return oss.str();
}

void read()
{

}

void write()
{

}

void compute()
{

}

void eval()
{

}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	read();
	compute();
	write();

	return 0;
}
#ifndef EVAL_H
#define EVAL_H
#include <vector>
#include "types.h"
using namespace std;
int eval(int &,vector<Order>&,int&);
#endif
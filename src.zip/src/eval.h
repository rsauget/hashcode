#ifndef EVAL_H
#define EVAL_H
#include <vector>
using namespace std;
int eval(vector<vector<int> > &t, int &n, int &m);
#endif
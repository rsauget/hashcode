#ifndef DRAW_H
#define DRAW_H
#include <vector>
#include "types.h"
using namespace std;
void draw(int &,int &,int &,vector<Warehouse> &, int);
#endif
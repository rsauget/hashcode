#include <vector>
#include "eval.h"
using namespace std;
int eval()
{
	return 0;
}